#include "common.h"

void recv_file(char *filename, int sock) {

}

void send_file(char *filename, int client_socket) {

}

